
abstract class PSOparticles {

  var velocity: Seq[Double]
  var position: Seq[Double]
  var pbest: Seq[Double]
  var pbestCost: Double


}